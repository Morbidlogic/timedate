#!/usr/bin/env bash
## Bash script to start timedate conky widget

sleep 5

killall conky

conky -c ~/.conky/timedate/timedate
