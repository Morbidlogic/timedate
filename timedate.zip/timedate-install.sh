#!/bin/sh

echo "hello"
echo "Installation of morbid logic's timedate starting..."

if [ ! -d ~/.conky ];then
        echo "There is no .conky directory in home..."
        echo "making directory .conky..."
        mkdir .conky 
fi      
echo "directory <<~/.conky>> Found..."
    
if [ -d timedate ];then
        echo "timedate directory Found..."
        echo "copying Files..."
        sleep 2
        mkdir ~/.conky/timedate 
        cp -r timedate ~/.conky/

        if [ -d timedate/.fonts ];then
                echo "font directory Found..."
                if [ ! -d ~/.fonts ];then
                    mkdir ~/.fonts
                fi    
                echo "installing fonts..."
                ls timedate/.fonts | xargs -IX cp timedate/.fonts/X ~/.fonts
            else
                echo "font directory not Found..."
                echo "visit https://github.com/Morbidlogic and download it..."
                exit
        fi
        echo "all files copied successfully..."
        echo "would you open conky manager? [y or n]"
        read answer
        if [ "$answer" == "y" ] ;then 
        conky-manager2
        fi
        exit
    else
        echo "timedate directory Not Found..."
        echo "visit https://github.com/Morbidlogic/timedate and download it..."
        exit    
fi        
